# S Robots FRC #11812

Site da equipe FRC da S Robots, da Escola SESI de Jaraguá do Sul (SC): o robô JarviS, o diário de bordo da temporada, fotos e formas de apoio.

- Instagram: [@srobots.frc](https://www.instagram.com/srobots.frc/)
- Projeto social: [Mini S](https://minis-sesi.github.io/#/)

## Como publicar no GitHub Pages

1. Em **Settings → Pages**, escolha **Deploy from a branch**.
2. Selecione a branch `main` e a pasta `/ (root)` e salve.
3. Em 1 ou 2 minutos o site fica no ar em `https://<usuario>.github.io/<repositorio>/`.

## Adicionar fotos

As fotos ficam em `img/`. Para colocar uma nova na galeria, salve `NOME.jpg` (até 1600 px) e `NOME_m.jpg` (até 900 px) em `img/` e acrescente uma linha na lista `FOTOS` no fim do `index.html`.
